package com.sky.springcore.refernce;

public class StudentMarks {
	
	private int TotalMarks;

	public int getTotalMarks() {
		return TotalMarks;
	}

	public void setTotalMarks(int totalMarks) {
		TotalMarks = totalMarks;
	}

	public StudentMarks() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "StudentMarks [TotalMarks=" + TotalMarks + "]";
	}

	
}
