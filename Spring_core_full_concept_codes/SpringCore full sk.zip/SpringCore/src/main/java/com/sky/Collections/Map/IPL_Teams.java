package com.sky.Collections.Map;

import java.util.Map;

public class IPL_Teams {

	private int Team_Code;
	private Map<Integer, String> Team_Name;

	public int getTeam_Code() {
		return Team_Code;
	}

	public void setTeam_Code(int team_Code) {
		Team_Code = team_Code;
	}

	public Map<Integer, String> getTeam_Name() {
		return Team_Name;
	}

	public void setTeam_Name(Map<Integer, String> team_Name) {
		Team_Name = team_Name;
	}

}
