package com.sky.Collections.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sky.Collections.Hospital;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//link to config file
		ApplicationContext context = new ClassPathXmlApplicationContext("com/sky/Collections/Set/Config.xml");
		
		Country c =(Country) context.getBean("country");
		
		System.out.println("CountryCode : " +c.getCountryCode());
		System.out.println("CountryName : "+c.getCountryName());

	}

}
