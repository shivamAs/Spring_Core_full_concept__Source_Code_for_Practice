package com.sky.springcore.StereotypeCollections;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sky.springcore.refernce.Student;

public class Main {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("com/sky/springcore/StereotypeCollections/Config.xml");

		Student st=(Student) context.getBean("student");

		System.out.println(st);
		System.out.println(st.getName());
	  

	}

}
