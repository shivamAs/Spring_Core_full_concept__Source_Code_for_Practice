package com.sky.springcore.autowiringAnnotationbased;

public class Address {
	private String Streetname;
	private String city;
	public String getStreetname() {
		return Streetname;
	}
	public void setStreetname(String streetname) {
		Streetname = streetname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Address [Streetname = " + Streetname + ", city = " + city + "]";
	}
	
	
	

}
