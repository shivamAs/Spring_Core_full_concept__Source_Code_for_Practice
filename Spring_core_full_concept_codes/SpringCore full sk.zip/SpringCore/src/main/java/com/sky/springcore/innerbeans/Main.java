package com.sky.springcore.innerbeans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	AbstractApplicationContext context=	new ClassPathXmlApplicationContext("com/sky/springcore/innerbeans/Config.xml");
	
	Employee emp1 = (Employee) context.getBean("emp");
	
	System.out.println(emp1.hashCode());
	System.out.println(emp1);
	}

}
