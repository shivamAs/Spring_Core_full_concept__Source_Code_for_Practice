package com.sky.springcore.WithoutXML;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.sky.springcore.WithoutXML")
public class JavaConfig {
	

	
	//@Bean       ------ We can use @Bean also in place of @Component to create an Object without XML file........
	


}
