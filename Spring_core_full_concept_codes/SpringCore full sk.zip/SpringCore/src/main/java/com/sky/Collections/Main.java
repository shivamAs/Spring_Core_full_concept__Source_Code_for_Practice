package com.sky.Collections;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//link to config file
		ApplicationContext context = new ClassPathXmlApplicationContext("com/sky/Collections/Config.xml");
		
		Hospital h = (Hospital) context.getBean("hospital");
		
		System.out.println("Hospital_Name :  "+h.getName());
		System.out.println("Dept_Name :  "+h.getDept());

		
		
	}

}
