package com.sky.Collections.Set;

import java.util.Set;

public class Country {
	private int CountryCode;
   private Set<String>CountryName;
   
   
public int getCountryCode() {
	return CountryCode;
}
public void setCountryCode(int countryCode) {
	CountryCode = countryCode;
}
public Set<String> getCountryName() {
	return CountryName;
}
public void setCountryName(Set<String> countryName) {
	CountryName = countryName;
}
   
   
   
}

	
	
	