package com.sky.Collections.Property;

import java.util.Properties;

public class Hacking {

	private int ip_code;
	private Properties Hacking_Type;

	public int getIp_code() {
		return ip_code;
	}

	public void setIp_code(int ip_code) {
		this.ip_code = ip_code;
	}

	public Properties getHacking_Type() {
		return Hacking_Type;
	}

	public void setHacking_Type(Properties hacking_Type) {
		Hacking_Type = hacking_Type;
	}

}
