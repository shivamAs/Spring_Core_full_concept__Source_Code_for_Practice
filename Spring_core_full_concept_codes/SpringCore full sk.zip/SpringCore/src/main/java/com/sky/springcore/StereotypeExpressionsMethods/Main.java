package com.sky.springcore.StereotypeExpressionsMethods;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
public static void main(String[] args) {
	
	ApplicationContext context= new ClassPathXmlApplicationContext("com/sky/springcore/StereotypeExpressionsMethods/Config.xml");
	
	Variables v1 = (Variables) context.getBean("var");
	
//	System.out.println(v1.getX());
//	System.out.println(v1.getY());
//	System.out.println(v1.getZ());
//	System.out.println(v1.getE());
	
	System.out.println(v1);
}
}
