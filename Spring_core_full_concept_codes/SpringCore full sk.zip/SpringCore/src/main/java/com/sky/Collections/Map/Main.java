package com.sky.Collections.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sky.Collections.Set.Country;

public class Main {
	
	public static void main(String[] args) {
		
		//link to config file
		ApplicationContext context = new ClassPathXmlApplicationContext("com/sky/Collections/Map/Config.xml");
		
		IPL_Teams ip =(IPL_Teams) context.getBean("IPL_Teams");
		
		System.out.println("Team_Code : "+ip.getTeam_Code());
		System.out.println("Team_Name : "+ip.getTeam_Name());
		
		
		
		
	}

}
