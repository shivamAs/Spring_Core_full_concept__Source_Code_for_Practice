package com.sky.springcore.StereotypeExpressions;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("var")
public class Variables {

	@Value("#{22+11}")
	private int x;

	@Value("#{2+9+9+12+92}")
	private int y;

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	@Override
	public String toString() {
		return "Variables [x=" + x + ", y=" + y + "]";
	}

}
