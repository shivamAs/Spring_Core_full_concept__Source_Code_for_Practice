package com.sky.springcore.refernce;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext("com/sky/springcore/refernce/Config.xml");
		
		
		Student st = (Student) context.getBean("studentref");
		
		System.out.println("StudentName : "+st.getName());
		
		System.out.println("StudentMarks : "+st.getOb().getTotalMarks());
		
		System.out.println(st);
		
		
	}

}
