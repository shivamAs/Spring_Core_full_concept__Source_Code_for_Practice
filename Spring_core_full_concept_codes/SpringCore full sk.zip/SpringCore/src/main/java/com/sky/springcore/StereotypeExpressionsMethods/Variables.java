package com.sky.springcore.StereotypeExpressionsMethods;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("var")
public class Variables {
	 
	@Value("#{ 22+11+22 }")
	private int x;
	
	@Value("#{ 22+1+2+92+92 }")
	private int y;
	
//	@Value("# { T(java.lang.Math).sqrt(144)  }")
//	private double z;
	
	@Value("#{  T(java.lang.Math).PI }")
	private double e;

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

//	public double getZ() {
//		return z;
//	}
//
//	public void setZ(double z) {
//		this.z = z;
//	}

	public double getE() {
		return e;
	}

	public void setE(double e) {
		this.e = e;
	}

	@Override
	public String toString() {
		return "Variables [x=" + x + ", y=" + y + ", e=" + e + "]";
	}
	
	

}
