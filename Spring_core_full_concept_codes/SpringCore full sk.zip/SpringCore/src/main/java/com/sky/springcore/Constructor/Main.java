package com.sky.springcore.Constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext("com/sky/springcore/Constructor/Config.xml");
		Person p = (Person) context.getBean("person");
		System.out.println(p);
		
		
		Certi cr = (Certi) context.getBean("certi");
		System.out.println(cr);

	}

}
